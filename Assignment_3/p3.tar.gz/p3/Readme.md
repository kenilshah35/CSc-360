

"# CSc-360 - Assignment 3 - A simple file system"

" How to run:

First you need to extract the p3.tar.gz into a folder using tar -zxvf p3.tar.gz. In order to compile the source codes, you can simply put 'make' in the console.

To run diskinfo: ./diskinfo disk.IMA

To run diskget: ./diskget disk.IMA ANS1.PDF

To run diskput: ./diskput disk.IMA /subdir1/subdir2/foo.txt

"
