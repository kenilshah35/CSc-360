"# CSc-360 - Assignment 2 Airline check in system" 

"
How to run:

First you need to extract the p2.tar.gz into a folder using tar -zxvf p2.tar.gz. 
In order to compile the source codes, you can simply put 'make' in the console. 

The program will accept one parameter on the command line:

./ACS customers.txt
		where customers.txt is the name of the input file.
"